package com.example.demo.payload.request;

public @interface NotBlank {

}
