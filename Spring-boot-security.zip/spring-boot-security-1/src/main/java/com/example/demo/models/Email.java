package com.example.demo.models;

public @interface Email {

}
